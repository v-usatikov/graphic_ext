__version__ = '0.1.0'
from .gr_field import GraphicField, GraphicObjekt